typedef enum { false, true } bool; // Provide C++ style 'bool' type in C
bool readpgm( char *filename );
